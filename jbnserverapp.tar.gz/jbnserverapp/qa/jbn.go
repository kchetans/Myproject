package main

import (
	"log"
	_ "os"
	"runtime"

	_ "github.com/auth0/go-jwt-middleware"
	_ "github.com/iris-contrib/middleware/basicauth"
	"github.com/joybynature/jbnserverapp/qa/routes"
	"github.com/kataras/iris"
)

// *****************************************************************************
// Application Logic
// *****************************************************************************

func init() {
	// Verbose logging with file name and line number
	log.SetFlags(log.Lshortfile)

	// Use all CPU cores
	runtime.GOMAXPROCS(runtime.NumCPU())
}

func main() {

	//Set JWT for authentication from Auth0
	// jwtMiddleware := jwtmiddleware.New(jwtmiddleware.Options{
	// 	ValidationKeyGetter: func(token *jwt.Token) (interface{}, error) {
	// 		decoded, err := base64.URLEncoding.DecodeString("MXs1Bs5oN7hpeiPLUixZudArZCdaDeHGUhmmUuYZwQLqH0ee-Zewqp-gB8JXyeFV")
	// 		if err != nil {
	// 			return nil, err
	// 		}
	// 		return decoded, nil
	// 	},
	// })
	/*authConfig := basicauth.Config{
		Users:      map[string]string{"myusername": "mypassword", "mySecondusername": "mySecondpassword"},
		Realm:      "Authorization Required", // if you don't set it it's "Authorization Required"
		ContextKey: "user",                   // if you don't set it it's "auth"
		Expires:    time.Duration(30) * time.Minute,
	}
	authentication := basicauth.New(authConfig)*/

	/*
	   iris.Get("/mysecret", authentication, func(ctx *iris.Context) {
	       username := ctx.GetString("user") //  the Contextkey from the authConfig
	       ctx.Write("Hello authenticated user: %s ", username)
	   })
	*/

	//Set Middlewares
	// iris.Use(errorLogger)
	// crs := cors.New(cors.Options{}) // options here
	// iris.Use(crs)                   // register the middleware

	//Set Routes
	routes.RegisterQARoutes()
	routes.RegisterTagRoutes()
	routes.RegisterAdminRoutes()

	//Set QuestionAnswer routes

	iris.Listen(":3000")
}

func myUsersMiddleware1(ctx *iris.Context) {
	println("From users middleware 1 ")
	ctx.Next()
}
func myUsersMiddleware2(ctx *iris.Context) {
	println("From users middleware 2 ")
	ctx.Next()
}
