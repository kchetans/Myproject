package controller

import (
	"log"
	"time"

	"github.com/joybynature/jbnserverapp/qa/model"
	"github.com/kataras/iris"
	"gopkg.in/mgo.v2"
)

const (
	MongoDBHosts = "127.0.0.1"
	AuthDatabase = "jbndevdb"
	//AuthUserName = "jbnuser"
	//AuthPassword = "wellbeing123$"
	Database     = "jbndevdb"
)

var (
	mongoSession *mgo.Session
	err          error
)

func init() {
	// We need this object to establish a session to our MongoDB.
	mongoDBDialInfo := &mgo.DialInfo{
		Addrs:    []string{MongoDBHosts},
		Timeout:  60 * time.Second,
		Database: AuthDatabase,
		//Username: AuthUserName,
		//Password: AuthPassword,
	}

	// Create a session which maintains a pool of socket connections
	// to our MongoDB.
	mongoSession, err = mgo.DialWithInfo(mongoDBDialInfo)
	if err != nil {
		log.Fatalf("CreateSession: %s\n", err)
	}

	mongoSession.SetMode(mgo.Monotonic, true)
}

func AddQuestionHandler(c *iris.Context) {
	println("inside1")
	model.AddQuestion(c, mongoSession)
	println("inside2")
	c.Write("ADD QUESTION HANDLER")
}

func QATopAnswerHandler(c *iris.Context) {
	println("From users middleware 1 ")
	model.GetQuestionsWithTopAnswer(c, mongoSession)
	c.Write("QA LIST WITH TOP ANSWERS")
}

func QADetailHandler(c *iris.Context) {
	// Retrieve the parameter name
	questionId := c.Param("qid")

	c.Write("TBD" + questionId)
}

func RelatedQuestionHandler(c *iris.Context) {
	// Retrieve the parameter name
	category := c.Param("cat")
	c.Write("TBD" + category)
}

func DeleteQuestionHandler(c *iris.Context) {
	// Retrieve the parameter name
	questionId := c.Param("qid")

	c.Write("TBD" + questionId)
}

func SearchQAHandler(c *iris.Context) {
	// Retrieve the parameter name
	searchText := c.Param("text")

	c.Write("TBD" + searchText)
}

func AddAnswerHandler(c *iris.Context) {
	c.Write("TBD")
	model.AddAnswerToQuestion(c, mongoSession)
}

func GetAllAnswerCommentsHandler(c *iris.Context) {
	// Retrieve the parameter name
	answerId := c.Param("aid")

	c.Write("TBD" + answerId)
}

func MyQuestionsHandler(c *iris.Context) {
	// Retrieve the parameter name
	userId := c.Param("userid")

	c.Write("TBD" + userId)
}

func MyAnswersHandler(c *iris.Context) {
	// Retrieve the parameter name
	userId := c.Param("userid")

	c.Write("TBD" + userId)
}

func AddCommentHandler(c *iris.Context) {
	// Retrieve the parameter name
	answerId := c.Param("aid")
	model.AddComment(c, mongoSession)
	c.Write("TBD" + answerId)
}

func ReviseQuestionHandler(c *iris.Context) {
	// Retrieve the parameter name
	questionId := c.Param("qid")
	model.ReviseQuestion(c,mongoSession)
	c.Write("TBD" + questionId)
}

func DeleteAnswerHandler(c *iris.Context) {
	// Retrieve the parameter name
	questionId := c.Param("qid")
	answerId := c.Param("aid")

	c.Write("TBD" + questionId)
	c.Write("TBD" + answerId)
}

func AddEmoxHandler(c *iris.Context) {
	// Retrieve the parameter name
	answerId := c.Param("aid")
	model.AddEmox(c, mongoSession)
	c.Write("TBD" + answerId)
}

//TAGS
func tagHandler(c *iris.Context) {

}

func categoryHandler(c *iris.Context) {
	// Retrieve the parameter name
	tagParentId := c.Param("tagparentcode")
	tagLevelId := c.Param("taglevel")

	c.Write("TBD" + tagLevelId + tagParentId)

}
