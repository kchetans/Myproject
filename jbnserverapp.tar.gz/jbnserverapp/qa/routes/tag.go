package routes

import (
	_"github.com/joybynature/jbnserverapp/qa/controller"
	_"github.com/kataras/iris"
	//"github.com/kataras/iris-contrib/middleware/basicauth"
)

func RegisterTagRoutes() {
	//iris.Get("/api/v1/qatag",  controller.tagHandler)
	//iris.Get("/api/v1/qatag/:tagparentcode/tag/:taglevel",  controller.categoryHandler)
}
