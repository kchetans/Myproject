package routes

import (
	"github.com/joybynature/jbnserverapp/qa/controller"
	"github.com/kataras/iris"
  //"github.com/kataras/iris-contrib/middleware/basicauth"
)

func RegisterQARoutes() {

    //Get all Question with top Answer for specific category
    iris.Get("/api/v1/qa/qalist/:cat",  controller.QATopAnswerHandler)

    //Get all detail for a specific question id
   // iris.Get("/api/v1/qa/qadetail/:qid",  controller.QADetailHandler)

   // iris.Get("/api/v1/qa/relatedquestion/:cat",  controller.RelatedQuestionHandler)

    //iris.Post("/api/v1/qa/deletequestion/:qid",  controller.DeleteQuestionHandler)

    //iris.Get("/api/v1/qa/search/:text",  controller.SearchQAHandler)

    iris.Post("/api/v1/qa/addquestion",  controller.AddQuestionHandler)

    iris.Post("/api/v1/qa/addanswer",  controller.AddAnswerHandler)

   // iris.Get("/api/v1/qa/:qid/qacomment/:aid",  controller.GetAllAnswerCommentsHandler)

   // iris.Get("/api/v1/qa/myquestions/:userid",  controller.MyQuestionsHandler)

   // iris.Get("/api/v1/qa/myanswers/:userid",  controller.MyAnswersHandler)

    iris.Post("/api/v1/qa/addcomment",  controller.AddCommentHandler)

    iris.Post("/api/v1/qa/addrevision",  controller.ReviseQuestionHandler)

   // iris.Get("/api/v1/qa/:qid/deleteanswer/:aid",  controller.DeleteAnswerHandler)

    iris.Post("/api/v1/qa/addqaemox",  controller.AddEmoxHandler)
}
