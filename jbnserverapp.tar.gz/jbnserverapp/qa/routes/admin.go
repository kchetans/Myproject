package routes

import (
	//"github.com/joybynature/jbnserverapp/qa/controller"
//	"github.com/kataras/iris"
	//"github.com/kataras/iris-contrib/middleware/basicauth"
)

func RegisterAdminRoutes() {
	//iris.Get("/api/v1/qa/postqaweb",  massUploadQAHandler)
}
