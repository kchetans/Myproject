package model

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/joybynature/jbnserverapp/util"
	"github.com/kataras/iris"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

type Author struct {
	UserID         bson.ObjectId `json:"userid" bson:"userid"`
	Name           string        `json:"name" bson:"name"`
	ImageURL       string        `json:"imageurl" bson:"imageurl"`
	Followers      int           `json:"followers" bson:"followers"`
	SingleLineDesc string        `json:"singlelinedesc" bson:"singlelinedesc"`
}

type Answer struct {
	AnswerID        bson.ObjectId  `json:"answerid" bson:"answerid"`
	Text            string         `json:"text" bson:"text"`
	ImageURL        string         `json:"imageurl" bson:"imageurl"`
	VideoURL        string         `json:"videourl" bson:"videourl"`
	Author          Author         `json:"author" bson:"author"`
	PostDateTime    time.Time      `json:"postdatetime" bson:"postdatetime"`
	EmoactionScales EmoactionScale `json:"emoactionscale" bson:"emoactionscale"`
	Emoactions      []Emoaction    `json:"emoactions" bson:"emoactions"`
	Status          string         `json:"status" bson:"status"`
	Comments        []Comment      `json:"comment" bson:"comment"`
	CommentCount    int            `json:"commentcount" bson:"commentcount"`
	//EmoxCount	int		`json:"emoxcount" bson:"emoxcount"'
}

type EmoactionScale struct {
	EmoxRatio int `json:"emoxratio" bson:"emoxratio"`
	Anger     int `json:"anger" bson:"anger"`
	Sad       int `json:"sad" bson:"sad"`
	OK        int `json:"ok" bson:"ok"`
	Happy     int `json:"happy" bson:"happy"`
	Awesome   int `json:"awesome" bson:"awesome"`
}

type Emoaction struct {
	EmoxText     string    `json:"emoxtext" bson:"emoxtext"`
	Author       Author    `json:"author" bson:"author"`
	EmoxDateTime time.Time `json:"emoxdatetime" bson:"emoxdatetime"`
}

type QuestionRevision struct {
	RevisionText     string    `json:"revisiontext" bson:"revisiontext"`
	RevisionDateTime time.Time `json:"revisiondatetime" bson:"revisiondatetime"`
}

type RelatedProduct struct {
	SKU         string `json:"sku" bson:"sku"`
	ProductName string `json:"productname" bson:"productname"`
	ImageURL    string `json:"imageurl" bson:"imageurl"`
	Rating      string `json:"rating" bson:"rating"`
}

type RelatedQuestion struct {
	Text string `json:"text" bson:"text"`
}

type Comment struct {
	CommentID    bson.ObjectId `json:"commentid" bson:"commentid"`
	ParentID     int           `json:"parentid" bson:"parentid"`
	PostText     string        `json:"posttext" bson:"posttext"`
	Author       Author        `json:"author" bson:"author"`
	PostDateTime time.Time     `json:"postdatetime" bson:"postdatetime"`
}

type UnwindQuestionAnswer struct {
	QAID             bson.ObjectId      `json:"_id" bson:"_id"`
	Title            string             `json:"title" bson:"title"`
	Revision         []QuestionRevision `json:"revision" bson:"revision"`
	Author           Author             `json:"author" bson:"author"`
	PostDateTime     time.Time          `json:"postdatetime" bson:"postdatetime"`
	Status           string             `json:"status" bson:"status"`
	QATags           []string           `json:"qatags" bson:"qatags"`
	QuestionFollwers int                `json:"questionfollowers" bson:"questionfollowers"`
	QAViews          int                `json:"qaviews" bson:"qaviews"`
	Answer           Answer             `json:"answer" bson:"answer"`
	RelatedProduct   []RelatedProduct   `json:"relatedproducts" bson:"relatedproducts"`
	RelatedQuestion  []RelatedQuestion  `json:"relatedquestions" bson:"relatedquestions"`
	BGImageURL       string             `json:"bgimageurl" bson:"bgimageurl"`
	AnswerCount      int                `json:"answercount" bson:"answercount"`
}

type Jbntags struct {
	TagID         bson.ObjectId `json:"_id" bson:"_id"`
	TagName       string        `json:"tagname" bson:"tagname"`
	TagCode       int           `json:"tagcode" bson:"tagcode"`
	TagLevel      int           `json:"taglevel" bson:"taglevel"`
	TagParentCode int           `json:"tagparentcode" bson:"tagparentcode"`
	ImageURL      string        `json:"imageurl" bson:"imageurl"`
}

type QuestionAnswer struct {
	QAID             bson.ObjectId      `json:"_id" bson:"_id"`
	Title            string             `json:"title" bs	on:"title"`
	Revision         []QuestionRevision `json:"revision" bson:"revision"`
	Author           Author             `json:"author" bson:"author"`
	PostDateTime     time.Time          `json:"postdatetime" bson:"postdatetime"`
	Status           string             `json:"status" bson:"status"`
	QATags           []string           `json:"qatags" bson:"qatags"`
	QuestionFollwers int                `json:"questionfollowers" bson:"questionfollowers"`
	QAViews          int                `json:"qaviews" bson:"qaviews"`
	Answer           []Answer           `json:"answer" bson:"answer"`
	RelatedProduct   []RelatedProduct   `json:"relatedproducts" bson:"relatedproducts"`
	RelatedQuestion  []RelatedQuestion  `json:"relatedquestions" bson:"relatedquestions"`
	BGImageURL       string             `json:"bgimageurl" bson:"bgimageurl"`
	AnswerCount      int                `json:"answercount" bson:"answercount"`
}

type Question struct {
	Title  string
	Author string //can be anonymous
	Tags   []string
}

type AddAnswerData struct{
	Qid				string
	Text            string         
	ImageURL        string       
	VideoURL        string       
	Author          string       
}

type AddCommentData struct{
	
	Aid				    string
	PostText 			string
	Author				string 
}

type AddRevisionData struct{
	
	Qid				    string
	RevisionText 		string
	Author				string 
}

type AddEmoxData struct{
	
	Qid				    string
	Aid					string			
	EmoxText		 		string
	Author				string 
}


type Response struct {
}

func AddQuestion(c *iris.Context, mongoSession *mgo.Session) {
	var authorInfo = Author{}
	fmt.Println("inside Add Question")
	//Retrieve all the form data
	question := Question{}
	err := c.ReadForm(&question)
	fmt.Println("question " + question.Title)
	if err != nil {
		fmt.Println("Error when reading Add question form: " + err.Error())
	}

	//Validate Form data
	isValid, errMsg := validateAddQuestion(question)

	if !isValid {
		qaValidationResult := map[string]interface{}{"code": util.ERRCODE_QA502, "message": "Error", "result": errMsg}
		validationResp, err := json.Marshal(qaValidationResult)
		if err != nil {
			fmt.Println("Add Question Validation Error " + err.Error())
		}
		c.JSON(iris.StatusOK, validationResp)
	} else { //Valida Form data
		//Get a mongo db connection
		sessionCopy := mongoSession.Copy()
		defer sessionCopy.Close()

		// Get a collection to execute the query against.
		collection := sessionCopy.DB("jbndevdb").C("questionanswer")

		index := mgo.Index{
			Key:        []string{"title"},
			Unique:     true,
			DropDups:   true,
			Background: true,
			Sparse:     true,
		}

		err = collection.EnsureIndex(index)
		if err != nil {
			fmt.Println("Error Creating index" + err.Error())
		}
		//check for anonymous author
		if question.Author != "anonymous" {
			//get the user id from user sessions
			//fill the Author struct
			authorInfo = getUserFromSession()
		} else { //Set Anonymous users
			//			authorInfo = new(Author)
			authorInfo.UserID = bson.NewObjectId()
			authorInfo.Name = "Anonymous"
			authorInfo.Followers = 0
			authorInfo.ImageURL = ""
			authorInfo.SingleLineDesc = "Be invisible"
		}
		//Add QA Tags

		fmt.Println("AUTHORwewew" + authorInfo.Name)
		//Add Question
		qDataInfo := &QuestionAnswer{QAID: bson.NewObjectId(), Title: question.Title, PostDateTime: time.Now(), Status: "Active", Author: authorInfo}
		data, _ := json.MarshalIndent(qDataInfo, "", "    ")
		fmt.Println("DATA -" + string(data))
		err = collection.Insert(qDataInfo)

		if err != nil {
			fmt.Println("Adding question " + err.Error())
		}

		//Question added successfully , respond success json to the client
		qaAddQuestionResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "Success", "result": "Question Added Successfully"}
		resp, err := json.Marshal(qaAddQuestionResult)
		if err != nil {
			fmt.Println("Add Question REsult " + err.Error())
		}

		c.JSON(iris.StatusOK, resp)
	}
}

//Validate Add question form data
func validateAddQuestion(question Question) (isValid bool, errorMessage string) {
	vErrors := []string{
		"Question title cannot be blank",
		"Question title cannot be more than 30 words",
	}
	questiontitlestring := question.Title
	qCharacterCount := strings.Count(questiontitlestring,"")
	fmt.Println(qCharacterCount)
	/*qWordList := strings.Split(question.Title, " ")
	qWordCount := len(qWordList)*/

	//Check question title
	if question.Title == "" { //checkIsBlank
		return false, vErrors[0]
	} else if qCharacterCount >= 375 { //checkWordCount
		return false, vErrors[1]
	}
	//Valid form data
	return true, ""
}

func getUserFromSession() (author Author) {
	authorInfo := new(Author)
	authorInfo.UserID = bson.NewObjectId()
	authorInfo.Name = "JBN Admin"
	authorInfo.Followers = 1110
	authorInfo.ImageURL = ""
	authorInfo.SingleLineDesc = "Joybynature Admin"

	return *authorInfo
}

func  GetQuestionsWithTopAnswer(c *iris.Context, mongoSession *mgo.Session) {
	category := c.Param("cat")
	//c.Write(category)
    if category != " "{
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()
	 var qa []QuestionAnswer
	
	collection := sessionCopy.DB("jbndevdb").C("questionanswer")

	operation1 := bson.M{
		"$match": bson.M{
			"status": "Active",
			//"qatags": category,/**************************remove cat*********************************/
		},
	}

	operation2 := bson.M{
		"$project": bson.M{"_id": 1, "title": 1, "revision": 1, "bgimageurl": 1, "author": 1, "postdatetime": 1, "status": 1, "qatags": 1, "followers": 1, "qaviews": 1,"answercount": 1,
			"answer": bson.M{
				"$filter": bson.M{"input": "$answer", "as": "ans", "cond": bson.M{"$eq": []string{"$$ans.status", "Active"}}},
			},
			"relatedproducts": 1, "relatedquestions": 1,
		},
	}
    operation3 := bson.M{"$project":bson.M{"_id":1,"title":1,"bgimageurl":1,"author":1,"postdatetime":1,"status":1,"qatags":1,"questionfollowers":1,"qaviews":1,"answercount":bson.M{"$size": "$answer",},"oneanswer":bson.M{"$slice":[]interface{}{"$answer",-1,},},},}

	operation4:= bson.M{"$project":bson.M{"_id":1,"title":1,"bgimageurl":1,"author":1,"postdatetime":1,"status":1,"qatags":1,"questionfollowers":1,"qaviews":1,"answercount":1,"answer":"$oneanswer",},}


	operation5:= bson.M{"$project":bson.M{"_id":1,"title":1,"bgimageurl":1,"author":1,"postdatetime":1,"status":1,"qatags":1,"questionfollowers":1,"qaviews":1,"answercount":1,"answer":bson.M{"answerid":1,"text":1,"author":1,"imageurl":1,"videourl":1,"postdatetime":1,"emoactions":1,"emoactionscale":1,"status":1,"commentcount":1},},}

	operation6 := bson.M{"$sort" : bson.M{ "postdatetime" :-1,},}
	
	operations := []bson.M{operation1,operation2,operation3,operation4,operation5,operation6}
	pipe := collection.Pipe(operations)
	err := pipe.All(&qa)
	if err != nil {
		fmt.Println("Question with top answer result err " + err.Error())
	}	
		qatopanswerResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "Success", "result":qa}
		resp,err:= json.Marshal(qatopanswerResult)
		if err != nil {
			fmt.Println("Add Question REsult " + err.Error())
		}

		//c.JSON(iris.StatusOK, resp)
		c.Write(string(resp))	
}else{
	qatopanswerResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "tag not avaliable"}
		resp, err := json.Marshal(qatopanswerResult)
		if err != nil {
			fmt.Println("Add Question REsult " + err.Error())
		}

		c.JSON(iris.StatusOK, resp)
}
	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")
}

func (qa *QuestionAnswer) GetQADetail(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")
}

func (qa *QuestionAnswer) GetRelatedQuestions(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")
}

func (qa *QuestionAnswer) DeleteQuestion(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")

}

func (qa *QuestionAnswer) SearchQA(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")

}

func  AddAnswerToQuestion(c *iris.Context, mongoSession *mgo.Session) {
	var authorInfo = Author{}
	fmt.Println("inside Add Answer")
	//Retrieve all the form data
	answer := AddAnswerData{}
	err := c.ReadForm(&answer)
	fmt.Println("answer " + answer.Text)
	if err != nil {
		fmt.Println("Error when reading Add answer form: " + err.Error())
	}

	//Validate Form data
	isValid, errMsg := validateAddAnswer(answer)

	if !isValid {
		qaValidationResult := map[string]interface{}{"code": util.ERRCODE_QA502, "message": "Error", "result": errMsg}
		validationResp, err := json.Marshal(qaValidationResult)
		if err != nil {
			fmt.Println("Add Answer Validation Error " + err.Error())
		}
		c.JSON(iris.StatusOK, validationResp)
		c.Write(string(validationResp))
	} else { //Valida Form data
		//Get a mongo db connection
		sessionCopy := mongoSession.Copy()
		defer sessionCopy.Close()

		// Get a collection to execute the query against.
		collection := sessionCopy.DB("jbndevdb").C("questionanswer")
		//check for anonymous author
		if answer.Author != "anonymous" {
			//get the user id from user sessions
			//fill the Author struct
			authorInfo = getUserFromSession()
		} else { //Set Anonymous users
			//			authorInfo = new(Author)
			authorInfo.UserID = bson.NewObjectId()
			authorInfo.Name = "Anonymous"
			authorInfo.Followers = 0
			authorInfo.ImageURL = ""
			authorInfo.SingleLineDesc = "Be invisible"
		}
		fmt.Println("AUTHORwewew" + authorInfo.Name)
		//Add answer
		answerinfo := []Answer{Answer{AnswerID:bson.NewObjectId(),Text:answer.Text,ImageURL:answer.ImageURL,VideoURL:answer.VideoURL,Author:authorInfo,Status:"Active",PostDateTime:time.Now()}}
		qa := &QuestionAnswer{Answer:answerinfo}
		qid:= bson.ObjectIdHex(answer.Qid)
		data, _ := json.MarshalIndent(qa, "", "    ")
		fmt.Println("DATA -" + string(data))
		matchQueri := bson.M{"_id":qid}		
		change := bson.M{"$push":bson.M{"answer":bson.M{"$each":answerinfo}}}
		err = collection.Update(matchQueri, change)
		
		if err != nil {
			fmt.Println("Adding Answer " + err.Error())
		}

		//Answer added successfully , respond success json to the client
		qaAddAnswerResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "Success", "result": "Answer Added Successfully"}
		resp, err := json.Marshal(qaAddAnswerResult)
		if err != nil {
			fmt.Println("Add Answer REsult " + err.Error())
		}

		c.JSON(iris.StatusOK, resp)
		c.Write(string(resp))
	}
}

//Validate Add answer form data
func validateAddAnswer(answer AddAnswerData) (isValid bool, errorMessage string) {
	vErrors := []string{
		"Answer text cannot be blank",
		"Answer text cannot be more than 10000 characters",
	}
	answerstring := answer.Text
	aCharacterCount := strings.Count(answerstring," ")
	/*qWordList := strings.Split(answer.Text, " ")
	qWordCount := len(qWordList)*/

	//Check answer text
	if answer.Text == "" { //checkIsBlank
		return false, vErrors[0]
	} else if aCharacterCount >= 10000 { //checkWordCount
		return false, vErrors[1]
	}
	//Valid form data
	return true, ""
}

func (qa *QuestionAnswer) GetAllAnswerComments(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")

}

func (qa *QuestionAnswer) GetMyQuestions(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")

}

func (qa *QuestionAnswer) GetMyAnswers(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")

}

func  AddComment(c *iris.Context, mongoSession *mgo.Session) {
	var authorInfo = Author{}
	fmt.Println("inside Add Comment")
	//Retrieve all the form data
	comment := AddCommentData{}
	err := c.ReadForm(&comment)
	fmt.Println("Comment " + comment.PostText)
	fmt.Println("Answerid " + comment.Aid)
	if err != nil {
		fmt.Println("Error when reading Add comment form: " + err.Error())
	}

	//Validate Form data
	isValid, errMsg := validateAddComment(comment)

	if !isValid {
		qaValidationResult := map[string]interface{}{"code": util.ERRCODE_QA502, "message": "Error", "result": errMsg}
		validationResp, err := json.Marshal(qaValidationResult)
		if err != nil {
			fmt.Println("Add Comment Validation Error " + err.Error())
		}
		c.JSON(iris.StatusOK, validationResp)
		c.Write(string(validationResp))
	} else { //Valida Form data
		//Get a mongo db connection
		sessionCopy := mongoSession.Copy()
		defer sessionCopy.Close()

		// Get a collection to execute the query against.
		collection := sessionCopy.DB("jbndevdb").C("questionanswer")
		//check for anonymous author
		if comment.Author != "anonymous" {
			//get the user id from user sessions
			//fill the Author struct
			authorInfo = getUserFromSession()
		} else { //Set Anonymous users
			//			authorInfo = new(Author)
			authorInfo.UserID = bson.NewObjectId()
			authorInfo.Name = "Anonymous"
			authorInfo.Followers = 0
			authorInfo.ImageURL = ""
			authorInfo.SingleLineDesc = "Be invisible"
		}
		fmt.Println("AUTHORwewew" + authorInfo.Name)
		//Add comment
		commentdata := []Comment{Comment{CommentID:bson.NewObjectId(),PostText:comment.PostText,Author:authorInfo,PostDateTime:time.Now()}}
		answerdata :=[]Answer{Answer{Comments:commentdata}}
		qa := &QuestionAnswer{Answer:answerdata}
		aid:= bson.ObjectIdHex(comment.Aid)
		data, _ := json.MarshalIndent(qa, "", "    ")
		fmt.Println("DATA -" + string(data))
		matchQueri := bson.M{"answer.answerid":aid}		
		change := bson.M{"$push":bson.M{"answer.$.comment":bson.M{"$each":commentdata}}}
		err = collection.Update(matchQueri, change)
		
		if err != nil {
			fmt.Println("Adding Comment " + err.Error())
		}

		//Comment added successfully , respond success json to the client
		qaAddCommentResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "Success", "result": "Comment Added Successfully"}
		resp, err := json.Marshal(qaAddCommentResult)
		if err != nil {
			fmt.Println("Add Comment REsult " + err.Error())
		}

		c.JSON(iris.StatusOK, resp)
		c.Write(string(resp))
	}
}

//Validate Add comment form data
func validateAddComment(comment AddCommentData) (isValid bool, errorMessage string) {
	vErrors := []string{
		"Comment Post cannot be blank",
		"Comment Post cannot be more than 10000 characters",
	}
	posttextstring := comment.PostText
	cCharacterCount := strings.Count(posttextstring,"")
	fmt.Println("comment character",cCharacterCount)
	//Check comment post
	if comment.PostText == "" { //checkIsBlank
		return false, vErrors[0]
	} else if cCharacterCount >= 10000 { //checkWordCount
		return false, vErrors[1]
	}
	//Valid form data
	return true, ""
}



func ReviseQuestion(c *iris.Context, mongoSession *mgo.Session) {
	var authorInfo = Author{}
	fmt.Println("inside Add Revision Question")
	//Retrieve all the form data
	revision := AddRevisionData{}
	err := c.ReadForm(&revision)
	fmt.Println("Question revision " + revision.RevisionText)
	fmt.Println("Question id " + revision.Qid)
	if err != nil {
		fmt.Println("Error when reading Add revision form: " + err.Error())
	}

	//Validate Form data
	isValid, errMsg := validateAddRevision(revision)

	if !isValid {
		qaValidationResult := map[string]interface{}{"code": util.ERRCODE_QA502, "message": "Error", "result": errMsg}
		validationResp, err := json.Marshal(qaValidationResult)
		if err != nil {
			fmt.Println("Add Question Revision Validation Error " + err.Error())
		}
		c.JSON(iris.StatusOK, validationResp)
		c.Write(string(validationResp))
	} else { //Valida Form data
		//Get a mongo db connection
		sessionCopy := mongoSession.Copy()
		defer sessionCopy.Close()

		// Get a collection to execute the query against.
		collection := sessionCopy.DB("jbndevdb").C("questionanswer")
		//check for anonymous author
		if revision.Author != "anonymous" {
			//get the user id from user sessions
			//fill the Author struct
			authorInfo = getUserFromSession()
		} else { //Set Anonymous users
			//			authorInfo = new(Author)
			authorInfo.UserID = bson.NewObjectId()
			authorInfo.Name = "Anonymous"
			authorInfo.Followers = 0
			authorInfo.ImageURL = ""
			authorInfo.SingleLineDesc = "Be invisible"
		}
		fmt.Println("AUTHORwewew" + authorInfo.Name)
		//Add question revision
		questionrevisiondata := []QuestionRevision{QuestionRevision{RevisionText:revision.RevisionText,RevisionDateTime:time.Now()}}
		qa := &QuestionAnswer{Revision:questionrevisiondata}
		qid:= bson.ObjectIdHex(revision.Qid)
		data, _ := json.MarshalIndent(qa, "", "    ")
		fmt.Println("DATA -" + string(data))
		
		matchQueri := bson.M{"_id":qid}		
		change := bson.M{"$push":bson.M{"revision":bson.M{"$each":questionrevisiondata}}}
		err = collection.Update(matchQueri, change)
		
		if err != nil {
			fmt.Println("Adding Revision " + err.Error())
		}

		//Revision added successfully , respond success json to the client
		qaAddCommentResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "Success", "result": "Question Revision Added Successfully"}
		resp, err := json.Marshal(qaAddCommentResult)
		if err != nil {
			fmt.Println("Add Comment REsult " + err.Error())
		}

		c.JSON(iris.StatusOK, resp)
		c.Write(string(resp))
	}
}

//Validate Add Question Revision form data
func validateAddRevision(revision AddRevisionData) (isValid bool, errorMessage string) {
	vErrors := []string{
		"Revision text cannot be blank",
		"Revision text cannot be more than 500 characters",
	}
	revisiontextstring := revision.RevisionText
	rCharacterCount := strings.Count(revisiontextstring,"")
	fmt.Println("Question Revision character",rCharacterCount)
	//Check Question Revision text
	if revision.RevisionText == "" { //checkIsBlank
		return false, vErrors[0]
	} else if rCharacterCount >= 500 { //checkWordCount
		return false, vErrors[1]
	}
	//Valid form data
	return true, ""
}

func (qa *QuestionAnswer) DeleteAnswer(c *iris.Context, mongoSession *mgo.Session) {
	sessionCopy := mongoSession.Copy()
	defer sessionCopy.Close()

	// Get a collection to execute the query against.
	//	collection := sessionCopy.DB("Database").C("QuestionAnswer")

}

func AddEmox(c *iris.Context, mongoSession *mgo.Session) {
	var authorInfo = Author{}
	fmt.Println("inside Add Emox")
	//Retrieve all the form data
	emox := AddEmoxData{}
	err := c.ReadForm(&emox)
	fmt.Println("Emox text" + emox.EmoxText)
	fmt.Println("Question id " + emox.Qid)
	fmt.Println("Answer id " + emox.Aid)
	if err != nil {
		fmt.Println("Error when reading Add Emox form: " + err.Error())
	}

	//Validate Form data
	isValid, errMsg := validateAddEmox(emox)

	if !isValid {
		qaValidationResult := map[string]interface{}{"code": util.ERRCODE_QA502, "message": "Error", "result": errMsg}
		validationResp, err := json.Marshal(qaValidationResult)
		if err != nil {
			fmt.Println("Add Emox Validation Error " + err.Error())
		}
		c.JSON(iris.StatusOK, validationResp)
		c.Write(string(validationResp))
	} else { //Validate Form data
		//Get a mongo db connection
		sessionCopy := mongoSession.Copy()
		defer sessionCopy.Close()

		// Get a collection to execute the query against.
		collection := sessionCopy.DB("jbndevdb").C("questionanswer")
		//check for anonymous author
		if emox.Author != "anonymous" {
			//get the user id from user sessions
			//fill the Author struct
			authorInfo = getUserFromSession()
		} else { //Set Anonymous users
			//			authorInfo = new(Author)
			authorInfo.UserID = bson.NewObjectId()
			authorInfo.Name = "Anonymous"
			authorInfo.Followers = 0
			authorInfo.ImageURL = ""
			authorInfo.SingleLineDesc = "Be invisible"
		}
		fmt.Println("AUTHORwewew" + authorInfo.Name)
		//Add emox
		emoxdata := []Emoaction{Emoaction{EmoxText:emox.EmoxText,Author:authorInfo,EmoxDateTime:time.Now()}}
		answerdata :=[]Answer{Answer{Emoactions:emoxdata}}
		qa := &QuestionAnswer{Answer:answerdata}
		
		qid:= bson.ObjectIdHex(emox.Qid)
		aid:= bson.ObjectIdHex(emox.Aid)
		data, _ := json.MarshalIndent(qa, "", "    ")
		fmt.Println("DATA -" + string(data))
		
		matchQueri := bson.M{"$and":[]interface{}{bson.M{"_id":qid},bson.M{"answer.answerid":aid}}}		
		change1 := bson.M{"$inc":bson.M{"answer.$.emoactionscale."+emox.EmoxText:1}}
		change2 := bson.M{"$push":bson.M{"answer.$.emoactions":bson.M{"$each":emoxdata}}}
		
		err = collection.Update(matchQueri, change1)
		
		if err != nil {
			fmt.Println("Add Emox change1 " + err.Error())
		}
		
		err = collection.Update(matchQueri, change2)
		
		if err != nil {
			fmt.Println("Add Emox change2" + err.Error())
		}

		//Emox added successfully , respond success json to the client
		qaAddEmoxResult := map[string]interface{}{"code": util.ERRCODE_QA501, "message": "Success", "result": "Emox Added Successfully"}
		resp, err := json.Marshal(qaAddEmoxResult)
		if err != nil {
			fmt.Println("Add Emox REsult " + err.Error())
		}

		c.JSON(iris.StatusOK, resp)
		c.Write(string(resp))
	}
}

//Validate Add Question Revision form data
func validateAddEmox(emox AddEmoxData) (isValid bool, errorMessage string) {
	vErrors := []string{
		"Emox text not found",
		
	}
	//Check Question Revision text
	if emox.EmoxText == "" { //checkIsBlank
		return false, vErrors[0]
	} 
	//Valid form data
	return true, ""
}