/*
Use your favourite build tool to fill this file which will contain the
../app/*.js and the .../vendor/*.js contents. 

I suggest you do it using 'gulp', but its your decision, you can use webpack also.
*/